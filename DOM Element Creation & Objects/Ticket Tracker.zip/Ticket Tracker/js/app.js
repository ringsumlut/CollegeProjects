var ticket = {
  state: "State",
  issue: "Issue",
};

var state = document.createElement("div");
var issue = document.createElement("div");

function open() {}
function close() {}
function inProgress() {}
